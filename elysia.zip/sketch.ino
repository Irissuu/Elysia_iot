#include <LiquidCrystal_I2C.h>
#include <math.h>

LiquidCrystal_I2C lcd(0x27, 20, 4);

#define ADC_PIN 35       
const float LINEAR_MAX_C = 150.0;  
const float SUPER_LIMIAR_C = 105.0;

void setup() {
  Serial.begin(115200);
  pinMode(ADC_PIN, INPUT);

  lcd.init();
  lcd.backlight();
}

void loop() {
  int adc = analogRead(ADC_PIN);   
  float celsius = (adc / 4095.0f) * LINEAR_MAX_C;

  String mensagem = "Temperatura: " + String(celsius, 1) + (char)223 + "C";

  Serial.println(mensagem);

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Monitorando...");
  
  lcd.setCursor(0,1);
  lcd.print(mensagem);

  lcd.setCursor(0,2);
  if(celsius >= SUPER_LIMIAR_C){
    lcd.print("SUPERAQUECIMENTO!");
  } else {
    lcd.print("Normal");
  }

  delay(300);
}
